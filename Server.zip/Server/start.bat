@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

:difficulty_choice
cls
echo ==============================================
echo       SERVER DIFFICULTY SELECTION
echo ==============================================
echo Peaceful
echo Easy [Default]
echo Normal
echo Hard
echo ==============================================
set "diff=1"
set /p diff="Select difficulty (0-3) [Default: 1]: "

if "%diff%"=="0" set "diff_val=0" & goto gamemode_choice
if "%diff%"=="1" set "diff_val=1" & goto gamemode_choice
if "%diff%"=="2" set "diff_val=2" & goto gamemode_choice
if "%diff%"=="3" set "diff_val=3" & goto gamemode_choice
goto difficulty_choice

:gamemode_choice
cls
echo ==============================================
echo       GAME MODE SELECTION
echo ==============================================
echo Survival [Default]
echo Creative
echo Adventure
echo ==============================================
set "gm=0"
set /p gm="Select game mode (0-2) [Default: 0]: "

if "%gm%"=="0" set "gm_val=0" & goto apply_settings
if "%gm%"=="1" set "gm_val=1" & goto apply_settings
if "%gm%"=="2" set "gm_val=2" & goto apply_settings
goto gamemode_choice

:apply_settings
cls
echo Applying settings...

if exist server.properties (
    (for /f "tokens=1* delims==" %%A in (server.properties) do (
        set "line=%%A"
        set "val=%%B"
        if "!line!"=="difficulty" (
            echo difficulty=!diff_val!
        ) else if "!line!"=="gamemode" (
            echo gamemode=!gm_val!
        ) else (
            if "!val!"=="" (echo !line!=) else (echo !line!=!val!)
        )
    )) > server.properties.tmp
    move /y server.properties.tmp server.properties >nul
)

cls
echo ==============================================
echo       HOW TO JOIN THE SERVER (TUTORIAL)
echo ==============================================
echo  1. Open your launcher (BetaCraft).
echo  2. Select and run version 1.5.2.
echo  3. Click "Multiplayer" in the game menu.
echo  4. Click "Direct Connect" and enter: 127.0.0.1
echo ==============================================
echo.
set /p ready="Press ENTER to start the server..."
cls
java -Xms2G -Xmx2G -jar minecraft_server.1.5.2.jar nogui
pause
